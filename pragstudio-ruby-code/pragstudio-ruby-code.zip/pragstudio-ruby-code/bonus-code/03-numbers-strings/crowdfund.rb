project1 = 'Project ABC'
project2 = 'Project LMN'
project3 = 'Project XYZ'
funding1 = 1000

puts "#{project1} has $#{funding1} in funding."

puts "Projects: \n\t#{project1}\n\t#{project2}\n\t#{project3}"