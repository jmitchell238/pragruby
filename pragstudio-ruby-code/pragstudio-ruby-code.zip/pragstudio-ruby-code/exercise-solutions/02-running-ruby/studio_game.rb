puts "Welcome!"

greeting = "Welcome!"
3.times do
  puts greeting.upcase
end
 
puts Time.now